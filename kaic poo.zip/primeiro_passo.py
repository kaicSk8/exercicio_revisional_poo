python3 -m venv myenv
source myenv/bin/activate


pip install django


django-admin startproject book_manager