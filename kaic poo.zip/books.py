cd book_manager
python manage.py startapp books
